#! /usr/bin/bash
#  
#      - Little Simple Wallpaper Changer -
# 
#  This program is free software; you can redistribute it and/or modify
#  it under the terms of the GNU General Public License as published by
#  the Free Software Foundation; either version 2, or (at your option)
#  any later version.
# 
#  This program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANT-ABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.
# 
#  You should have received a copy of the GNU General Public License
#  along with this program; if not, write to the Free Software
#  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA
#  02111-1307, USA. https://www.gnu.org/licenses/gpl-3.0.en.html
# 
#  Written by: Ronald van Eendenburg <ronald@oponzezolder.nl> twitter: @_lswc_
#
# 
# Little Simple Wallpaper Changer, or in short lswc, is a standalone wallpaper changer designed to run in the user environment to change the wallpaper in a time period somewhere between 1 and 5 minutes, decided by a randomizer. You can change the program to fit at you needs or leave 'as is' to enjoy the pictures you like on your desktop.
# These can be the pictures of your family, the artwork you created or anything that fits on a .jpg. It is especially designed on and for use on Ubuntu (which is a trademark of Canonical).
# Use on any other linux version may acquire changes in the program although it runs on any Gnome3 desktop like ubuntu, fedora or suse. Other versions are named different and are ajusted to work on other shells like mint or Lubuntu.
#  
#
# Intention of creating this program:
# -----------------------------------
# The intention is to provide you with a tiny but powerful tool to change the wallpaper of your computer. Simplified so everyone could understand the steps to install and to use.
# To use it as is, or to use it as a building block for your own design.
#  
# 
# For who this program can be handy:
# ----------------------------------
# When you need a wallpaper changer as minimal you can get, very low in resources. 
# For those who use computers offline or not connected to the internet. 
# For those who administer computers by ssh and don't have a graphic interface to do settings, it is possible to scp the program, install it and to set the path to the folder which is filled with .jpg files by hand in a file called ~/.config/lswc/homepath.conf. Add the absolute path as the first line and the graphic window asking for a folder won't come up and the cycle of selecting a .jpg starts, rotating the change of wallpapers.
# 
# 
# What this program does:
# -----------------------
# Ask you to point to a folder, filled with .jpg files. This chosen path is then stored in a file 'homepath.conf' to keep this setting along the boot-cycles of your computer. 
# It checks for the existens of the conf file and reads again the path.
# It selects a .jpg file, also random chosen, and registers that file as the current wallpaper.
# Pauses for a random time period (between 1 and 5 minutes) and again selects a .jpg file from the folder, and so on and on. 
# 
#
# What this program does not do:
# ------------------------------
# Alter settings on your pc you don't want.
# Download in the background, or collect statistics
#
#
# Install - so easy ;-)
# ----------------------
# After you have read this file, close this after you have read the following.
#
# Create a folder with a name you like and copy your pictures with a .jpg extension to that folder.
#
# Now in the folder where you unpacked the 'LSWC files, rightclick and choose 'Open in Terminal' - or go to this folder in a terminal.
# type: 'bash ./README_and_install.sh'    (or start typing RE.. and hit TAB and the name will be completed (tab completion) then hit enter.
# Then this installer installs the program lswc into the folder it creates; .local/scripts/lswc/lswc, in your home folder.
# After that it records your homepath in a file called homefolder.conf in .config/lswc and then the program starts.
# A little graphic square opens on your desktop, asking you in wich folder you store your .jpg files. From there you can browse your files..
#
#  little sidenote: to unhide hidden files and folders in Nautilus (filebrowser) press CTRL-H, or press CTRL-H to hide again your hidden files. Hidden file and folders are stored with a dot before their name.
#  (I store my wallpapers in a hidden folder .wallpapers - see sidenote a couple of lines above this one)
#
#
# Removal
# --------
# For removal of the entire program, stop the service with 'pkill lswc', delete the 'scripts' folder from .local, delete the 'lswc' folder from .config and remove the lswc.desktop file from .config/autostart. 
#  
#
#
#  For questions or alike: drop me a line on twitter or email
#             email <ronald@oponzezolder.nl> twitter: @_lswc_
#
#
#  end of README
#
#
#

mkdir -p ~/.local/scripts/lswc
cp lswc ~/.local/scripts/lswc/
chmod u+x ~/.local/scripts/lswc/lswc
mkdir -p ~/.config/autostart
cat <<DT>>  ${HOME}/.config/autostart/lswc.desktop
[Desktop Entry]
Name=Lswc
Exec=${HOME}/.local/scripts/lswc/lswc
Icon=python3
Terminal=false
Type=Application
Categories=GNOME;GTK;System;Utility
Comment[en_US.UTF-8]=Rotate your Wallpaper
DT

python3 ~/.local/scripts/lswc/lswc & >/dev/null 2>/dev/null
echo " "
echo "Done! Save your work, Logout and Login, or reboot..  and enjoy your changing wallpaper.."
echo " "

